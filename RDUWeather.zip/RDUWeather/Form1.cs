﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.VisualBasic.FileIO;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
/// <summary>
/// Summary description for PAM's RDU Weather Application
/// </summary>

namespace RDUWeather
{
    public partial class Form1 : Form
    {
        private JsonSerializerSettings jsonsettings = new JsonSerializerSettings();
        public Form1()
        {
            InitializeComponent();
            this.Load += Form1_Load;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Setup the json environment
            jsonsettings.DefaultValueHandling = DefaultValueHandling.Populate;
            jsonsettings.StringEscapeHandling = StringEscapeHandling.EscapeNonAscii;
            jsonsettings.NullValueHandling = NullValueHandling.Include;
            jsonsettings.DateParseHandling = DateParseHandling.DateTime;
            // Initialize the form
            inputdate.Text = "";
            // Load the saved weather data
            if (!File.Exists(Path.GetDirectoryName(Application.ExecutablePath)+ "\\weather-data.csv"))
            {
                msgbox.Text = @"I can't find the historical weather data!";
            }
            else
            {
                TextFieldParser parser = new TextFieldParser(Path.GetDirectoryName(Application.ExecutablePath) + "\\weather-data.csv");
                parser.TextFieldType = FieldType.Delimited;
                parser.HasFieldsEnclosedInQuotes = false;
                parser.SetDelimiters(new string[] { "," });
                bool gotheader = false;
                while(!parser.EndOfData)
                {
                    string[] data = parser.ReadFields();
                    if (gotheader)
                    {
                        dataGridView1.Rows.Add(data);
                    }
                    gotheader = true; // Pass by the header
                }
            }
        }
        private void Button1_Click(object sender, EventArgs e)
        {
            // Example of capturing the object that fired the handler and changing a property
            // Button makeprediction = ((Button)sender);
            // makeprediction.BackColor = Color.Azure;
            // First validate the input date
            jsonoutput.Text = "";
            p_temp.Text = "";
            p_precip.Text = "";
            DateTime testdate = DateTime.Now;
            if (DateTime.TryParse(inputdate.Text, out testdate))
            {
                msgbox.Text = "Good to Go!";
            }
            else
            {
                msgbox.Text = "No Date Entered, using date and time of NOW!";
                testdate = DateTime.Now;
            }
            if (dataGridView1.RowCount >= dataGridView1.NewRowIndex+1)
            {
                // Calculate the answer from the data
                Prediction myguess = new Prediction();
                myguess.date = testdate;
                bool notfound = true;
                // Iterate through all the rows of the data
                dataGridView1.ClearSelection();
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Index < dataGridView1.NewRowIndex) // If the DataGridView has the property set for user to be able to add rows, the last one is null 
                    {
                        // Compensating for zero index
                        string themonth = (new string[] {"","January","February","March","April","May","June","July","August","September","October","November","December" })[testdate.Month];
                        if ((row.Cells["month"].Value.ToString().Trim() == themonth) && (row.Cells["dayofmonth"].Value.ToString() == testdate.Day.ToString()))
                        {
                            msgbox.Text += " Success! Predicted temp and precip have been determined.";
                            myguess.precip = float.Parse(row.Cells["normalprecip"].Value.ToString());
                            // Take the average of max and min
                            // NO ERROR HANDLING 
                            myguess.temp = (double.Parse((row.Cells["normalmax"].Value).ToString()) + double.Parse((row.Cells["normalmin"].Value).ToString())) / 2; // Average
                            notfound = false;
                            row.Selected = true;
                            dataGridView1.FirstDisplayedScrollingRowIndex = row.Index;
                            break;
                        }
                    }
                }
                if (notfound)
                {
                    msgbox.Text += " Date not found! Temp and date values are given for today";
                    myguess.temp = 70;
                    myguess.precip = (float)0.1;
                }
                //
                // Output the data
                p_temp.Text = myguess.temp.ToString();
                p_precip.Text = myguess.precip.ToString();
                jsonoutput.Text = JsonConvert.SerializeObject(myguess, typeof(Prediction), jsonsettings);
            }
            else
            {
                msgbox.Text += " The historical data file is empty!";
            }
        }
        private class Prediction
        {
            public DateTime date;
            public double temp;
            public float precip;
        }
    }
}
